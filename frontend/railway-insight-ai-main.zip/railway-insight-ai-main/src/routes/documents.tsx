import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { FileSpreadsheet, FileText, FileType2, Image as ImageIcon, Mail, Upload } from "lucide-react";
import { AppShell, PageHeader } from "@/components/kmrl/AppShell";
import { useApp } from "@/lib/kmrl/store";
import { daysUntil, type KDocument } from "@/lib/kmrl/data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/documents")({
  validateSearch: (s: Record<string, unknown>) => ({ doc: typeof s['doc'] === "string" ? (s['doc'] as string) : undefined }),
  head: () => ({
    meta: [
      { title: "Unified Document Intelligence — KMRL Ops Intelligence" },
      {
        name: "description",
        content:
          "Index KMRL PDFs, spreadsheets, Word files, emails and scanned images with automatic classification and entity extraction.",
      },
      { property: "og:title", content: "Unified Document Intelligence — KMRL" },
      {
        property: "og:description",
        content: "Auto-classified KMRL documents with extracted departments, dates, trainsets and employee IDs.",
      },
    ],
  }),
  component: DocumentsPage,
});

const ICONS = {
  PDF: FileText,
  XLSX: FileSpreadsheet,
  DOCX: FileType2,
  IMAGE: ImageIcon,
  EMAIL: Mail,
} as const;

function DocumentsPage() {
  const { docs, addDoc, lang, log, t } = useApp();
  const { doc: docParam } = Route.useSearch();
  const [openId, setOpenId] = useState<string | null>(docParam ?? docs[0]?.id ?? null);
  const [filter, setFilter] = useState<string>("All");
  const [ingesting, setIngesting] = useState<string | null>(null);

  const types = ["All", ...Array.from(new Set(docs.map((d) => d.type)))];
  const list = docs.filter((d) => filter === "All" || d.type === filter);
  const open = docs.find((d) => d.id === openId) ?? list[0];

  function handleFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    const file = files[0]!;
    setIngesting(file.name);
    const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
    const format: KDocument["format"] =
      ext === "xlsx" || ext === "xls" || ext === "csv"
        ? "XLSX"
        : ext === "docx" || ext === "doc"
          ? "DOCX"
          : ["png", "jpg", "jpeg", "webp"].includes(ext)
            ? "IMAGE"
            : ext === "eml" || ext === "msg"
              ? "EMAIL"
              : "PDF";

    setTimeout(() => {
      const id = `DOC-${1200 + Math.floor(Math.random() * 700)}`;
      const doc: KDocument = {
        id,
        title: file.name.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " "),
        titleMl: `അപ്‌ലോഡ് ചെയ്ത രേഖ — ${file.name}`,
        fileName: file.name,
        format,
        type: format === "XLSX" ? "Job Card" : format === "IMAGE" ? "Incident Report" : "Maintenance Log",
        department: "Operations",
        language: "en",
        uploadedBy: "Duty Controller (You)",
        uploadedAt: new Date().toISOString(),
        trainsets: ["TS-07"],
        employeeIds: ["KM-2291"],
        confidence: format === "IMAGE" ? 0.74 : 0.87,
        status: format === "IMAGE" ? "Needs Review" : "Indexed",
        tags: ["uploaded", "auto-classified"],
        chunks: [
          {
            id: `${id}#p1s1`,
            page: 1,
            section: format === "IMAGE" ? "OCR — Page 1" : "Extracted content — Page 1",
            text: `Auto-extracted content from ${file.name}. Classification pipeline identified an operations document referencing trainset TS-07 and employee KM-2291. Entities: 1 trainset, 1 employee ID, 1 date. Text is now searchable across the semantic index.`,
            textMl: `${file.name} എന്ന ഫയലിൽ നിന്ന് സ്വയമേവ എടുത്ത ഉള്ളടക്കം. TS-07 ട്രെയിൻസെറ്റും KM-2291 ജീവനക്കാരനും തിരിച്ചറിഞ്ഞു.`,
          },
        ],
      };
      addDoc(doc);
      setOpenId(id);
      setIngesting(null);
      log({
        actor: "Duty Controller (You)",
        action: "UPLOAD",
        target: `${id} ${file.name}`,
        detail: `Format ${format}; classified as ${doc.type} at ${(doc.confidence * 100).toFixed(0)}% confidence.`,
      });
    }, 1200);
  }

  return (
    <AppShell>
      <PageHeader
        tag="Ingestion · Classification · Extraction"
        title={t("nav_documents")}
        subtitle="Every KMRL source — maintenance PDFs, job-card spreadsheets, Word circulars, scanned Malayalam logs and emails — is ingested into one index with automatic type, department, date, trainset and employee-ID extraction."
      />

      <label className="panel mb-5 flex cursor-pointer flex-wrap items-center gap-4 border-dashed p-5 hover:border-primary/60">
        <input
          type="file"
          className="hidden"
          onChange={(e) => handleFiles(e.target.files)}
          accept=".pdf,.xlsx,.xls,.csv,.docx,.doc,.png,.jpg,.jpeg,.eml"
        />
        <span className="grid size-11 place-items-center rounded-md bg-primary/15 text-primary">
          <Upload className="size-5" />
        </span>
        <span>
          <span className="block text-sm font-medium">{t("upload")}</span>
          <span className="mono-label">PDF · XLSX · DOCX · IMAGE (OCR) · EMAIL — max 20 MB</span>
        </span>
        {ingesting && (
          <span className="ml-auto animate-pulse text-xs text-accent">
            Indexing {ingesting} — OCR, chunking, classification…
          </span>
        )}
      </label>

      <div className="mb-4 flex flex-wrap gap-2">
        {types.map((ty) => (
          <button
            key={ty}
            onClick={() => setFilter(ty)}
            className={cn(
              "rounded-full border px-3 py-1 text-xs",
              filter === ty ? "border-primary bg-primary/15 text-primary" : "border-border text-muted-foreground",
            )}
          >
            {ty}
          </button>
        ))}
      </div>

      <div className="grid gap-4 xl:grid-cols-5">
        <div className="space-y-2 xl:col-span-3">
          {list.map((d) => {
            const Icon = ICONS[d.format];
            const exp = d.expiresOn ? daysUntil(d.expiresOn) : null;
            return (
              <button
                key={d.id}
                onClick={() => setOpenId(d.id)}
                className={cn(
                  "panel flex w-full items-start gap-3 p-3 text-left transition-colors",
                  open?.id === d.id ? "border-primary" : "hover:border-primary/40",
                )}
              >
                <span className="grid size-9 shrink-0 place-items-center rounded bg-secondary text-primary">
                  <Icon className="size-4" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-medium">
                    {lang === "ml" ? d.titleMl : d.title}
                  </span>
                  <span className="mono-label block truncate">
                    {d.id} · {d.fileName} · {d.department}
                  </span>
                  <span className="mt-1 flex flex-wrap gap-1">
                    <Tag>{d.type}</Tag>
                    <Tag>{d.format}</Tag>
                    <Tag>
                      {d.language === "bilingual" ? "EN + ML" : d.language === "ml" ? "മലയാളം" : "EN"}
                    </Tag>
                    <Tag tone={d.status === "Indexed" ? "ok" : d.status === "Processing" ? "warn" : "bad"}>
                      {d.status}
                    </Tag>
                    {exp !== null && (
                      <Tag tone={exp < 0 ? "bad" : exp <= 7 ? "warn" : "ok"}>
                        {exp < 0 ? `expired ${-exp}d` : `expires in ${exp}d`}
                      </Tag>
                    )}
                  </span>
                </span>
                <span className="mono-label shrink-0">{(d.confidence * 100).toFixed(0)}%</span>
              </button>
            );
          })}
        </div>

        <div className="panel h-fit p-5 xl:col-span-2">
          {open ? (
            <>
              <p className="mono-label">Extraction result · {open.id}</p>
              <h2 className="mt-1 text-lg font-semibold">{lang === "ml" ? open.titleMl : open.title}</h2>
              <dl className="mt-4 grid grid-cols-2 gap-3 text-xs">
                <Field label="Document type" value={open.type} />
                <Field label="Department" value={open.department} />
                <Field label="Uploaded by" value={open.uploadedBy} />
                <Field label="Uploaded at" value={new Date(open.uploadedAt).toLocaleString("en-IN")} />
                <Field label="Effective from" value={open.effectiveFrom ?? "—"} />
                <Field label="Expires on" value={open.expiresOn ?? "—"} />
                <Field label="Trainset IDs" value={(open.trainsets ?? ["—"]).join(", ")} />
                <Field label="Employee IDs" value={(open.employeeIds ?? ["—"]).join(", ")} />
                <Field label="Language" value={open.language} />
                <Field label="Classifier confidence" value={`${(open.confidence * 100).toFixed(0)}%`} />
              </dl>

              <p className="mono-label mt-5">Indexed passages ({open.chunks.length})</p>
              <div className="mt-2 space-y-3">
                {open.chunks.map((c) => (
                  <div key={c.id} className="rounded-md border border-border bg-secondary/40 p-3">
                    <p className="mono-label text-primary">
                      {t("page")} {c.page} · {c.section}
                    </p>
                    <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                      {lang === "ml" && c.textMl ? c.textMl : c.text}
                    </p>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <p className="text-sm text-muted-foreground">Select a document.</p>
          )}
        </div>
      </div>
    </AppShell>
  );
}

function Tag({ children, tone }: { children: React.ReactNode; tone?: "ok" | "warn" | "bad" }) {
  return (
    <span
      className={cn(
        "rounded border px-1.5 py-0.5 text-[10px]",
        tone === "ok"
          ? "border-success/40 bg-success/10 text-success"
          : tone === "warn"
            ? "border-accent/40 bg-accent/10 text-accent"
            : tone === "bad"
              ? "border-destructive/40 bg-destructive/10 text-destructive"
              : "border-border text-muted-foreground",
      )}
    >
      {children}
    </span>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="mono-label">{label}</dt>
      <dd className="mt-0.5 break-words text-foreground">{value}</dd>
    </div>
  );
}
